package application;

import java.util.List;

public class Application {

	// can have status as 'P' only if all 3 marks are 50 and above
	public String addStudent(Student student) throws Exception {
		return null;
	}

	public String calculateGrade(StudentReport studentReport) throws Exception {
		return null;
	}

	public List<StudentReport> getGradesForStudentsInRange(String range) throws Exception {
		return null;
	}
}
