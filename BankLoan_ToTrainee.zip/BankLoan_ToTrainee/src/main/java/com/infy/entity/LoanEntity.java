package com.infy.entity;


//Strictly follow class diagram
public class LoanEntity {
	
	// Your code goes here
	
}
