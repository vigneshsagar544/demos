package com.infy.dao;

import java.util.List;

import com.infy.model.Customer;
import com.infy.model.Loan;

public interface LoanDAO {
	
	public List<Customer> getReportByLoanType(String loanType) throws Exception;
	
	public Integer checkLoanAllotment(Integer customerId) throws Exception;
	
	public Integer applyLoan(Loan loan,Integer customerId) throws Exception;
	
	public List<Integer> closeLoan(String startsWith) throws Exception;
}
