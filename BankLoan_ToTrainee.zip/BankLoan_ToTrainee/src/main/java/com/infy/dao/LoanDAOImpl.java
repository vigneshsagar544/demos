package com.infy.dao;

import java.util.List;

import com.infy.model.Customer;
import com.infy.model.Loan;

public class LoanDAOImpl implements LoanDAO {

	
	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public List<Customer> getReportByLoanType(String loanType) throws Exception {
		
		// Your code goes here
		
		return null;
	}

	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public Integer checkLoanAllotment(Integer customerId) throws Exception {
		
		// Your code goes here
		
		return null;
	}

	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public Integer applyLoan(Loan loan, Integer customerId) throws Exception {
		
		// Your code goes here

		return null;
	}

	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public List<Integer> closeLoan(String startsWith) throws Exception {
		
		// Your code goes here
		
		return null;
	}
}
