package com.infy.test;


public class LoanServiceTest {
	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public void applyLoanInValidLoanTypeTest() throws Exception {

	}
	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public void applyLoanCustomerUnAvailableTest() throws Exception {

	}
	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public void applyLoanLoanAlreadyTakenTest() throws Exception {

	}

}
