package com.infy;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.model.Customer;
import com.infy.model.Loan;
import com.infy.service.LoanService;

@SpringBootApplication
public class BankLoanToTraineeApplication implements CommandLineRunner {
	
	@Autowired
	private LoanService service;
	
	@Autowired
	private Environment environment;
	

	public static void main(String[] args) {
		SpringApplication.run(BankLoanToTraineeApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		//applyLoan();
		//getReportByLoanType();
		closeLoan();

	}

	public void applyLoan() {
		try 
		{
			Integer customerId=2001;

			Loan loan=new Loan();
			loan.setLoanAmount(2000000.0);
			loan.setLoanType("PersonnalLoan");

			Integer loanId = service.applyLoan(loan, customerId);

			System.out.println(environment.getProperty("UserInterface.ALLOCATE_SUCCESS")+loanId);

		} catch (Exception e) {

			String message = environment.getProperty(e.getMessage());
			if (message == null) {
				message = environment.getProperty("General.EXCEPTION");
			}
			System.out.println("ERROR:" + message);
		}	
	}


	public void getReportByLoanType() 
	{
		String loanType="carloan";
		try 
		{
			List<Customer> customerDetails=service.getReportByLoanType(loanType);

			System.out.println("List of customers");
			System.out.println("==================");
			System.out.println("CustomerId   CustomerName    LoanId    LoanAmount      EMI");
			System.out.println("===========================================================");
			for (Customer customer : customerDetails) 
			{
				System.out.printf("%-15d%-15s%-10d%-15.1f%-15.1f",customer.getCustomerId(),customer.getCustomerName(),customer.getLoan().getLoanId(),customer.getLoan().getLoanAmount(),customer.getEmi());
				System.out.println();
			}

		} catch (Exception e) {

			String message = environment.getProperty(e.getMessage());
			if (message == null) {
				message = environment.getProperty("General.EXCEPTION");
			}
			System.out.println("ERROR:" + message);
		}
	}


	public void closeLoan() 
	{
		String customerName="M";
		List<Integer> loanIds=null;
		try 
		{
			loanIds=service.closeLoan(customerName);
			System.out.println("Closed LoanId's are");
			for(Integer loanId:loanIds)
			{
				System.out.println(loanId);
			}			
		} 
		catch (Exception e) 
		{

			String message = environment.getProperty(e.getMessage());
			if (message == null) 
			{
				message = environment.getProperty("General.EXCEPTION");
			}
			System.out.println("ERROR:" + message);
		}

	}

}

