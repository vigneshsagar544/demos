package com.infy.validator;


import com.infy.model.Loan;

public class Validator {

	//DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	public static void validate(Loan loan) throws Exception{
		// Your code goes here


	}

	// don't tamper with the signature
	public static Boolean validateLoanType(String loanType) {
		// Your code goes here


		return null;
	}

}
