drop table customer cascade constraints;
drop table loan cascade constraints;
drop sequence hibernate_sequence;
create sequence hibernate_sequence start with 2006 increment by  1;
create table customer (
    customer_id number(10) not null,
    date_of_birth date,
    emailid varchar2(20),
    name varchar2(20),
    primary key (customer_id)
);
create table loan (
    loan_id number(10) not null,
    amount double precision,
    issue_date date,
    cust_id number(10),
    primary key (loan_id)
);
alter table loan add constraint fk_cust_loan foreign key (cust_id) references customer; 


INSERT INTO customer (customer_id, emailid, name, date_of_birth) VALUES (1001,'steven@infy.com', 'Steven Martin', SYSDATE-7476);
INSERT INTO customer (customer_id, emailid, name, date_of_birth) VALUES (1002,'kevin@infy.com', 'Kevin Nelson', SYSDATE-11374);
INSERT INTO customer (customer_id, emailid, name, date_of_birth) VALUES (1003,'john@infy.com', 'John Matric', SYSDATE-12344);
INSERT INTO customer (customer_id, emailid, name, date_of_birth) VALUES (1004,'chan@infy.com', 'Chan mathew', SYSDATE-10344);
INSERT INTO customer (customer_id, emailid, name, date_of_birth) VALUES (1005,'jill@infy.com', 'Jill mathew', SYSDATE-11374);

INSERT INTO loan (loan_id,amount,issue_date,cust_id) values (2001,612345,SYSDATE-1000,1001);
INSERT INTO loan (loan_id,amount,issue_date,cust_id) values (2002,2289073,SYSDATE-500,1001);
INSERT INTO loan (loan_id,amount,issue_date,cust_id) values (2003,109376289,SYSDATE-800,1001);
INSERT INTO loan (loan_id,amount,issue_date,cust_id) values (2004,9912895,SYSDATE-1700,null);
INSERT INTO loan (loan_id,amount,issue_date,cust_id) values (2005,99027309,SYSDATE-2345,1004);

--commit;

select * from loan;
select * from customer;

