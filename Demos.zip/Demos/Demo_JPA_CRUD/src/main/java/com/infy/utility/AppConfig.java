package com.infy.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;


public class AppConfig {
	public static final Properties PROPERTIES;
	public static InputStream inputStream = null;
	static {
		try {
			String path=new File("").getAbsolutePath()+"/src/main/resources/configuration.properties";
			inputStream = new FileInputStream(new File(path));
		}
		catch (Exception exception) {
			LogManager.getLogger(AppConfig.class).error(exception.getMessage(),exception);
		}
		PROPERTIES = new Properties();
		try {
			PROPERTIES.load(inputStream);
		}
		catch (IOException exception) {
			LogManager.getLogger(AppConfig.class).error(exception.getMessage(),exception);
		}
	}
}
