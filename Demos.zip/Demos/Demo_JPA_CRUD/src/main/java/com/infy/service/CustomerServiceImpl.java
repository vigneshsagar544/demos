package com.infy.service;

import com.infy.dao.CustomerDAO;
import com.infy.dao.CustomerDAOImpl;
import com.infy.model.Customer;

public class CustomerServiceImpl implements CustomerService {

	private CustomerDAO customerDAO;


	public Customer getCustomer(Integer customerId) throws Exception {

		customerDAO=new CustomerDAOImpl();
		Customer customer=customerDAO.getCustomer(customerId);
		
		if(customer==null){
			throw new Exception("Service.CUSTOMER_UNAVAILABLE");
		}

		return customer;
	}


	public Integer addCustomer(Customer customer) throws Exception {

		customerDAO=new CustomerDAOImpl();

		if(customerDAO.getCustomer(customer.getCustomerId())!=null){
			throw new Exception("Service.CUSTOMER_ALREADY_EXISTS");
		}

		return customerDAO.addCustomer(customer);

	}



	public Integer updateCustomer(Integer customerId, String emailId)
			throws Exception {
		customerDAO=new CustomerDAOImpl();
		Customer customer=customerDAO.getCustomer(customerId);
		
		if(customer==null){
			throw new Exception("Service.CUSTOMER_UNAVAILABLE");
		}
		return customerDAO.updateCustomer(customerId, emailId);
	}

	
	
	public Integer deleteCustomer(Integer customerId) throws Exception {
		customerDAO=new CustomerDAOImpl();
		//Customer customer=customerDAO.getCustomer(customerId);
		
		/*if(customer==null){
			throw new Exception("Service.CUSTOMER_UNAVAILABLE");
		}*/
		return customerDAO.deleteCustomer(customerId);
	}

}
