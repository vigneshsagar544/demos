package com.infy.dao;

import com.infy.model.Account;



public interface AccountDAO {
	

	public String addAccount(Account account) throws Exception;

	
}
