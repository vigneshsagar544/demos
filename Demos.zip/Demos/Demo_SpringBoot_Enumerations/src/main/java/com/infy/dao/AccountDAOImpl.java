package com.infy.dao;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.entity.AccountEntity;
import com.infy.model.Account;


@Repository(value = "accountDao")
public class AccountDAOImpl implements AccountDAO {

	@Autowired
	EntityManager entityManager;

	@Override
	public String addAccount(Account account) throws Exception {

		AccountEntity accountEntity = new AccountEntity();
		accountEntity.setAccountId(account.getAccountId());
		accountEntity.setAccountNumber(account.getAccountNumber());
		accountEntity.setAccountStatus(account.getAccountStatus());
		accountEntity.setBalance(account.getBalance());
		
		accountEntity.setBranchId(account.getBranchId());
		
		entityManager.persist(accountEntity);
		
		return accountEntity.getAccountNumber();
		
	}
}