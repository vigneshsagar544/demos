package com.infy.model;

public enum AccountStatus {
	ACTIVE, INACTIVE;
}
