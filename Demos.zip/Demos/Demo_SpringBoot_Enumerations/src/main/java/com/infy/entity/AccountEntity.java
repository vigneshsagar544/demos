package com.infy.entity;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infy.model.AccountStatus;

@Entity
@Table(name = "ACCOUNT")
public class AccountEntity

{

	@Id
	private Integer accountId;

	private String accountNumber;

	private Integer branchId;

	private Double balance;

	

	@Enumerated(EnumType.STRING)
	private AccountStatus accountStatus;

	public Integer getAccountId() {

		return accountId;

	}

	public void setAccountId(Integer accountId) {

		this.accountId = accountId;

	}

	public String getAccountNumber() {

		return accountNumber;

	}

	public void setAccountNumber(String accountNumber) {

		this.accountNumber = accountNumber;

	}

	public Integer getBranchId() {

		return branchId;

	}

	public void setBranchId(Integer branchId) {

		this.branchId = branchId;

	}

	public Double getBalance() {

		return balance;

	}

	public void setBalance(Double balance) {

		this.balance = balance;

	}

	

	public AccountStatus getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(AccountStatus accountStatus) {
		this.accountStatus = accountStatus;
	}

	

}