package com.infy.service;

import java.util.List;

import com.infy.model.Customer;

public interface CustomerService {
	public Customer getCustomer(Integer customerId) throws Exception;
	public Integer addCustomer(Customer customer) throws Exception;
	public Integer updateCustomer(Integer customerId, String emailId) throws Exception;
	public Integer deleteCustomer(Integer id) throws Exception;
	public List<Customer> findAllCustomers() throws Exception;
	public String getCustomerName(Integer customerId) throws Exception;
}
