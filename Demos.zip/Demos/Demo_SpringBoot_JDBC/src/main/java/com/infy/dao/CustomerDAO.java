package com.infy.dao;

import java.util.List;

import com.infy.model.Customer;

public interface CustomerDAO {
	public Integer  addCustomer(Customer customer);
	public Customer getCustomer(Integer customerId);
	public List<Customer> findAllCustomers();
	public Integer deleteCustomer(Integer customerId);
	public Integer updateCustomer(Integer customerId, String emailId);
	public String getCustomerName(Integer customerId);
}
