package com.infy.api;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import com.infy.model.CabBooking;

public class CabBookingAPI {

	public ResponseEntity<String> bookCab(@RequestBody CabBooking cabBooking) throws Exception {
		return null;
	}

	public ResponseEntity<List<CabBooking>> getBookingDetails(@PathVariable Long mobileNo) throws Exception {
		return null;

	}

	public ResponseEntity<String> cancelBooking(@PathVariable Integer bookingId) throws Exception {
		return null;
	}

}
