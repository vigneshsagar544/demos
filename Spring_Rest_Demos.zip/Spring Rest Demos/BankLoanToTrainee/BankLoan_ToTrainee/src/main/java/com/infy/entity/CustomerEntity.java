package com.infy.entity;




//Strictly follow class diagram

public class CustomerEntity {
	
}
