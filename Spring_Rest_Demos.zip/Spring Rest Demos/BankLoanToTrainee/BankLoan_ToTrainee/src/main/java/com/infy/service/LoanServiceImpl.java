package com.infy.service;

import java.util.List;

import com.infy.dao.LoanDAO;
import com.infy.model.Customer;

//DONT MODIFY NAME OF CLASS
//DONT ADD/MODIFY/DELETE/COMMENT ANY METHOD
//DONT DELETE/MODIFY INSTANCE VARIABLE(IF PRESENT)
//DONT MODIFY ANNOTATIONS(IF PRESENT)
public class LoanServiceImpl implements LoanService {

	
	private LoanDAO loanDAO;

	

	public Integer sanctionLoan(Customer customer) throws Exception {
		
		
		return null;

	}

	
	public List<Customer> getReportByLoanType(String loanType) throws Exception {
		
		
		return null;
	}

}
