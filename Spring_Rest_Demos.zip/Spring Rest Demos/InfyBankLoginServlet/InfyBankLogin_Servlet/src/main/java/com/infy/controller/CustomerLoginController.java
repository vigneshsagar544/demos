package com.infy.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infy.model.CustomerLogin;
import com.infy.service.CustomerLoginService;
import com.infy.service.CustomerLoginServiceImpl;


@WebServlet("/LoginServlet")
public class CustomerLoginController extends HttpServlet {

	// the service method should be implemented
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// using the request object to set the CustomerLogin object from the
		// HTMLform
		CustomerLogin customerLogin = new CustomerLogin();
		customerLogin.setLoginName(request.getParameter("username"));
		customerLogin.setPassword(request.getParameter("password"));
		
		

		// invoking the authenticateCustomer() method
		CustomerLoginService customerService = new CustomerLoginServiceImpl();
		String message = customerService.authenticateCustomer(customerLogin);
		

		// creating PrintWriter object to generate the dynamic content for the
		// web page
		// note the usage of response object to create the PrintWriter object
		PrintWriter out = response.getWriter();

		// condition to check if the employee details are available
		if (message.equals("success")) {

			// if message is available
			// generate the HTML content to be displayed

			// these details are the actual dynamic content to be displayed
			out.write("<!doctype html>" + "<html>" + "<head>"
					+ "<title>InfyBank Login</title>" + "</head>" + "<body>"
					+ "<div align='center'>" + "<h3> Welcome "
					+ request.getParameter("username")+"."
					+ "</br></br> You have logged in successfully.<h3>"
					+ "</div>" + "</body>" + "</html>");
		} else {
			out.write("<!doctype html>"
					+ "<html>"
					+ "<head>"
					+ "<title>Error Login</title>"
					+ "</head>"
					+ "<body>"
					+ "<div align='center'>"
					+ "<h3> Invalid credentials, Please try again. <h3>"
					+ "</div>" + "</body>" + "</html>");
		}

	}
}
