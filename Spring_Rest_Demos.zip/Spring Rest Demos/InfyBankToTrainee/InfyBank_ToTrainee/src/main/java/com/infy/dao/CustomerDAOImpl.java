package com.infy.dao;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

import com.infy.model.Customer;

@Repository
public class CustomerDAOImpl implements CustomerDAO {	
	
	public List<Customer> getAllCustomer(){
		List<Customer> customerList=new ArrayList<>();
		
		
		Customer customer1=new Customer();
		customer1.setCustomerName("Tom");
		customer1.setCustomerId(1001);
		customer1.setCity("Washington");
		customer1.setEmailId("tom@infy.com");
		customer1.setStatus("Active");
		
		Customer customer2=new Customer();
		customer2.setCustomerName("Harry");
		customer2.setCustomerId(1002);
		customer2.setCity("New York");
		customer2.setEmailId("harry@infy.com");
		customer2.setStatus("Inactive");
		
		Customer customer3=new Customer();
		customer3.setCustomerName("Garry");
		customer3.setCustomerId(1003);
		customer3.setCity("Las Vegas");
		customer3.setEmailId("garry@infy.com");
		customer3.setStatus("Active");
		
		Customer customer4=new Customer();
		customer4.setCustomerName("Monica");
		customer4.setCustomerId(1004);
		customer4.setCity("New York");
		customer4.setEmailId("monica@infy.com");
		customer4.setStatus("Active");
		
		Customer customer5=new Customer();
		customer5.setCustomerName("John");
		customer5.setCustomerId(1005);
		customer5.setCity("Indianapolis");
		customer5.setEmailId("john@infy.com");
		customer5.setStatus("Inactive");
		
		
		customerList.add(customer1);
		customerList.add(customer2);
		customerList.add(customer3);
		customerList.add(customer4);
		customerList.add(customer5);
		
		return customerList;
	}
	
}
