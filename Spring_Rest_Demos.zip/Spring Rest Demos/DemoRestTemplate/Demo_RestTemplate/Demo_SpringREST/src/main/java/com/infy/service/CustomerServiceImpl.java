package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.dao.CustomerDAO;
import com.infy.model.Customer;

@Service(value = "customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;

	public Customer getCustomer(Integer customerId) throws Exception {

		Customer customer = customerDAO.getCustomer(customerId);
		if (customer == null) {
			throw new Exception("Service.CUSTOMER_UNAVAILABLE");
		}
		return customer;
	}

	public void addCustomer(Customer customer) throws Exception {
		if (customerDAO.getCustomer(customer.getCustomerId()) != null) {
			throw new Exception("Service.CUSTOMER_ALREADY_EXISTS");
		}
		customerDAO.addCustomer(customer);
	}

	public void updateCustomer(Integer customerId, String emailId) throws Exception {
		Customer customer = customerDAO.getCustomer(customerId);
		if (customer == null) {
			throw new Exception("Service.CUSTOMER_UNAVAILABLE");
		}		
		customerDAO.updateCustomer(customerId, emailId);
	}

	public void deleteCustomer(Integer customerId) throws Exception {
		Customer customer = customerDAO.getCustomer(customerId);
		if (customer == null) {
			throw new Exception("Service.CUSTOMER_UNAVAILABLE");
		}
		customerDAO.deleteCustomer(customerId);
	}

	public List<Customer> getAllCustomerDetails() throws Exception {
		List<Customer> customerList = customerDAO.getAllCustomerDetails();
		if (customerList == null) {
			throw new Exception("Service.NO_CUSTOMER_AVAILABLE");
		}
		return customerList;
	}
}
