package com.infy.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.infy.model.Customer;

@Repository(value = "customerDAO")
public class CustomerDAOImpl implements CustomerDAO {
	
	private Map<Integer, Customer> customers = new HashMap<Integer, Customer>();
	
	public CustomerDAOImpl() {
		customers.put(1,new Customer(1, "john@infy.com", "John"));
		customers.put(2,new Customer(2, "celina@infy.com", "Celina"));
	}
	
	public void addCustomer(Customer customer) throws Exception{
		customers.put(customer.getCustomerId(), customer);
	}
	public Customer getCustomer(Integer customerId) throws Exception{
		return customers.get(customerId);
	}
	public void updateCustomer(Integer customerId, String emailId) throws Exception{
		customers.get(customerId).setEmailId(emailId);
		
	}
	public void deleteCustomer(Integer customerId) throws Exception{
		customers.remove(customerId);
		
	}
	public List<Customer> getAllCustomerDetails(){
		return new ArrayList<>(customers.values());
		
	}
	
	

}