package com.infy;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.web.client.RestTemplate;

import com.infy.model.Customer;

@SpringBootApplication
public class DemoSpringBootRestTemplateApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication
				.run(DemoSpringBootRestTemplateApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		getCustomerDetails(2);
		Customer customer = new Customer();
		customer.setCustomerId(6);
		customer.setEmailId("peter@infy.com");
		customer.setName("Peter");
		addCustomer(customer);
		deleteCustomer(1);
		Customer customer1 = new Customer();
		customer1.setCustomerId(6);
		customer1.setEmailId("peter@infy.com");
		customer1.setName("Peter");
		updateCustomer(customer1);
		

	}

	public void getCustomerDetails(Integer customerId) {
		String url = "http://localhost:3557/infybank/customers/{customerId}";

		RestTemplate restTemplate = new RestTemplate();

		Customer customer = restTemplate.getForObject(url, Customer.class,
				customerId);

		System.out
				.println("Customer Details\n------------------------------------------");
		System.out.println("Customer Id: " + customer.getCustomerId());
		System.out.println("Customer Name: " + customer.getName());
		System.out.println("Email Id: " + customer.getEmailId());

	}

	public void addCustomer(Customer customer) {
		String url = "http://localhost:3557/infybank/customers";
		RestTemplate restTemplate = new RestTemplate();
		String response = restTemplate.postForObject(url, customer,String.class);
		System.out.println(response);
	}
	public void deleteCustomer(Integer customerId) {
		String url = "http://localhost:3557/infybank/customers/{customerId}";
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.delete(url,customerId);
		System.out.println("Customer deleted successfully");
	}
	
	public void updateCustomer(Customer customer) {
		String url = "http://localhost:3557/infybank/customers/{customerId}";
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.put(url,customer,customer.getCustomerId());
		System.out.println("Customer updated successfully");
	}
	
	
}
